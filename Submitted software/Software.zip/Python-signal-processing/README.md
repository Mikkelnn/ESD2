## install python packages

- `pip install matplotlib`
- `pip install pyserial`
- `pip install easygui`
- `pip install scipy`

## install ghostscript

<!-- `https://ghostscript.com/releases/gsdnld.html` -->

install `./gs10011w64.exe`

### Windows

Add following to enviorment variable "PATH"

- `C:\Program Files\gs\gs10.01.1\bin`
- `C:\Program Files\gs\gs10.01.1\temp`
